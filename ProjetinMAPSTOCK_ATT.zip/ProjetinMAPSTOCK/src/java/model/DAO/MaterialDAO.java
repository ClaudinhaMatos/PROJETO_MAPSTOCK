/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import java.sql.*;
import model.Material;
import config.ConectaDB;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Claudinha
 */
public class MaterialDAO {
    // Atrib
    
    //Métodos - CRUD
    // CADASTRAR - INSERIR NOVO MATERIAL NO BD
    public boolean cadastrar(Material p_material) throws ClassNotFoundException {
        Connection conn = null;        
        try {           
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();

            String sql = "INSERT INTO materiais (codigo, nome, fabricante, qtd_minima, preco_unit) VALUES ('"+ 
                         p_material.getId() +"', '"+ p_material.getNome() +"', '" + p_material.getFab() + "', '" 
                         + p_material.getQtd() + "', '" + p_material.getPreco()+ "')";            

            stmt.executeUpdate(sql); // grava material

            // inserir estoque inicial fictício
            inserirEstoqueInicial(p_material.getId(), 100);

            stmt.close();
            conn.close();

            System.out.println("Registro incluído com sucesso!");
            return true;

        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar material: " + ex.getMessage());
            return false;
        }        
    }
    
    //INSERE NOVA LINHA NO ESTOQUE ATUAL AO CADASTRAR MATERIAL
    public void inserirEstoqueInicial(int idMaterial, int quantidadeInicial) throws ClassNotFoundException {
    try {
        Connection conn = ConectaDB.conectar();
        String sql = "INSERT INTO estoque_atual (material_id, quantidade) VALUES (?, ?)";

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, idMaterial);
        stmt.setInt(2, quantidadeInicial);

        stmt.executeUpdate();
        stmt.close();
        conn.close();

        } catch (SQLException e) {
            System.out.println("Erro ao inserir estoque inicial: " + e.getMessage());
        }
    }
    
    // EDITAR - ATUALIZAR MATERIAL
    public boolean editar(Material p_material) throws ClassNotFoundException {
        Connection conn = null;

        try {
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();

            String sql = "UPDATE materiais SET "
                    + "nome = '" + p_material.getNome() + "', "
                    + "fabricante = '" + p_material.getFab() + "', "
                    + "qtd_minima = '" + p_material.getQtd() + "', "
                    + "preco_unit = '" + p_material.getPreco() + "' "
                    + "WHERE codigo = '" + p_material.getId() + "'";

            stmt.executeUpdate(sql);
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Erro ao editar: " + e.getMessage());
            return false;
        }
    }
    
    // EXCLUIR - APAGAR MATERIAL DO BD
    public boolean excluir(int codigo) throws ClassNotFoundException {
        Connection conn = null;

        try {
            conn = ConectaDB.conectar();
            Statement stmt = conn.createStatement();

            String sql = "DELETE FROM materiais WHERE codigo = '" + codigo + "'";

            stmt.executeUpdate(sql);
            conn.close();
            return true;

        } catch (SQLException e) {
            System.out.println("Erro ao excluir: " + e.getMessage());
            return false;
        }
    }

    
    //LISTAGEM DO BD - MATERIAIS CADASTRADOS
    public List<Material> listar() throws ClassNotFoundException {
    Connection conn = null;
    List<Material> lista = new ArrayList<>();

    try {
        conn = ConectaDB.conectar();
        Statement stmt = conn.createStatement();
        String sql = "SELECT codigo, nome, fabricante, qtd_minima, preco_unit FROM materiais";
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            Material mat = new Material();

            mat.setId(rs.getInt("codigo"));
            mat.setNome(rs.getString("nome"));
            mat.setFab(rs.getString("fabricante"));
            mat.setQtd(rs.getInt("qtd_minima"));
            mat.setPreco(rs.getFloat("preco_unit"));

            lista.add(mat);
        }

        rs.close();
        stmt.close();
        conn.close();

    } catch (SQLException ex) {
        System.out.println("Erro ao listar: " + ex.getMessage());
    }

    return lista;
}
    // BUSCAR MATERIAL POR ID
public Material buscarPorId(int id) throws ClassNotFoundException {
    Connection conn = null;
    Material mat = null;

    try {
        conn = ConectaDB.conectar();
        String sql = "SELECT * FROM materiais WHERE codigo = ?";
        
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);

        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            mat = new Material();
            mat.setId(rs.getInt("codigo"));
            mat.setNome(rs.getString("nome"));
            mat.setFab(rs.getString("fabricante"));
            mat.setQtd(rs.getInt("qtd_minima"));
            mat.setPreco(rs.getFloat("preco_unit"));
        }

        rs.close();
        stmt.close();
        conn.close();

    } catch (SQLException e) {
        System.out.println("Erro ao buscar por ID: " + e.getMessage());
    }

    return mat;
}


    
}
