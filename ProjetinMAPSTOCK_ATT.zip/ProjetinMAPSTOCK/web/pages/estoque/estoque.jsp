<%-- 
    Document   : estoque
    Created on : 27 de nov. de 2025, 23:18:45
    Author     : Claudinha
--%>

<%@page contentType="text/html; charset=UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="model.EstoqueAtual"%>
<%@page import="model.DAO.EstoqueAtualDAO"%>

<%
    EstoqueAtualDAO dao = new EstoqueAtualDAO();
    List<EstoqueAtual> lista = dao.listarEstoque();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Estoque Atual</title>
    <link rel="stylesheet" href="../css/pages/estoqueAtual.css">
</head>
<body>

<h2>Estoque Atual</h2>

<table border="1" cellpadding="6">
    <tr>
        <th>Código</th>
        <th>Nome</th>
        <th>Fabricante</th>
        <th>Quantidade em Estoque</th>
    </tr>

    <% for (EstoqueAtual e : lista) { %>
        <tr>
            <td><%= e.getMaterialId() %></td>
            <td><%= e.getNome() %></td>
            <td><%= e.getFabricante() %></td>
            <td><%= e.getQuantidade() %></td>
        </tr>
    <% } %>

</table>

</body>
</html>
