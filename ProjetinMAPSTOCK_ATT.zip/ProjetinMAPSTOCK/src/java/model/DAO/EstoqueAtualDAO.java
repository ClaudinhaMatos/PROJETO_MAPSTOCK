/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

/**
 *
 * @author Claudinha
 */
import config.ConectaDB;
import model.EstoqueAtual;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EstoqueAtualDAO {

    public List<EstoqueAtual> listarEstoque() throws ClassNotFoundException {
        List<EstoqueAtual> lista = new ArrayList<>();

        try {
            Connection conn = ConectaDB.conectar();
            String sql = 
                "SELECT ea.material_id, ea.quantidade, m.nome, m.fabricante " +
                "FROM estoque_atual ea " +
                "JOIN materiais m ON ea.material_id = m.codigo";

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                EstoqueAtual e = new EstoqueAtual();
                e.setMaterialId(rs.getInt("material_id"));
                e.setNome(rs.getString("nome"));
                e.setFabricante(rs.getString("fabricante"));
                e.setQuantidade(rs.getInt("quantidade"));

                lista.add(e);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println("Erro ao listar estoque: " + e.getMessage());
        }

        return lista;
    }
}