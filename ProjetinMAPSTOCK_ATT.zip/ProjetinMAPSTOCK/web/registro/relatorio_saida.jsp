<%-- 
    Document   : relatorio_mensal
    Created on : 26 de nov. de 2025, 00:24:22
    Author     : Claudinha
--%>

<%@page import="model.DAO.MaterialDAO"%>
<%@page import="model.DAO.EstoqueDAO"%>
<%@page import="model.DAO.RegistroSaidaDAO"%>
<%@page import="model.Material"%>
<%@page import="java.util.List"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    request.setCharacterEncoding("UTF-8");

    int mes = 0;
    if (request.getParameter("mes") != null) {
        mes = Integer.parseInt(request.getParameter("mes"));
    }

    MaterialDAO mdao = new MaterialDAO();
    EstoqueDAO edao = new EstoqueDAO();
    RegistroSaidaDAO rdao = new RegistroSaidaDAO();

    List<Material> materiais = mdao.listar();

    float totalGasto = (mes > 0) ? rdao.getTotalGastoMes(mes) : 0;
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Relatório Mensal</title>
        <style>
            table {
                width: 90%;
                margin: 25px auto;
                border-collapse: collapse;
            }
            th, td {
                border: 1px solid #444;
                padding: 8px 12px;
                text-align: center;
            }
            th {
                background: #e9e9e9;
            }
            h2, h3 {
                text-align: center;
            }
            body {
                font-family: Arial;
            }
        </style>
    </head>
    <body>

        <h2>Relatório Mensal de Saída</h2>

        <form method="get" action="relatorio_mensal.jsp" style="text-align:center;margin-bottom:20px;">
            <label>Mês:</label>
            <select name="mes">
                <option value="0">Selecione</option>
                <% for (int i = 1; i <= 12; i++) { %>
                    <option value="<%= i %>" <%= (i == mes ? "selected" : "") %>><%= i %></option>
                <% } %>
            </select>
            <button type="submit">Gerar</button>
        </form>

        <% if (mes > 0) { %>

        <table>
            <tr>
                <th>Material</th>
                <th>Preço Unit.</th>
                <th>Média de Saída</th>
                <th>Qtd Atual</th>
                <th>Qtd Mínima</th>
                <th>Necessita Reposição?</th>
                <th>Qtd a Repor</th>
            </tr>

            <%
                for (Material m : materiais) {

                    int estoqueAtual = edao.getEstoqueAtual(m.getId());
                    float mediaSaida = rdao.getMediaSaidasMaterial(m.getId(), mes);

                    boolean precisa = estoqueAtual < m.getQtd() || estoqueAtual < mediaSaida;
                    int qtdRepor = 0;

                    if (precisa) {
                        // repor para atingir mínimo + média esperada
                        qtdRepor = (int)((m.getQtd() + mediaSaida) - estoqueAtual);
                        if (qtdRepor < 0) qtdRepor = 0;
                    }
            %>

            <tr>
                <td><%= m.getNome() %></td>
                <td>R$ <%= m.getPreco() %></td>
                <td><%= mediaSaida %></td>
                <td><%= estoqueAtual %></td>
                <td><%= m.getQtd() %></td>

                <td><%= precisa ? "SIM" : "NÃO" %></td>
                <td><%= precisa ? qtdRepor : "-" %></td>
            </tr>

            <% } %>

        </table>

        <h3>Total gasto no mês: R$ <%= totalGasto %></h3>

        <% } %>

    </body>
</html>