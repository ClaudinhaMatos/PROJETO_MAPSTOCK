<%-- 
    Document   : entrada_relatorio
    Created on : 27 de nov. de 2025, 23:43:15
    Author     : Claudinha
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.DAO.EntradaDAO"%>
<%@page import="model.Entrada"%>
<%@page import="java.util.List"%>

<html>
<head>
    <title>Relatório Mensal de Entradas</title>
</head>
<body>

<h2>Relatório de Entradas no Mês</h2>

<form method="get">
    <select name="mes">
        <option value="1">Janeiro</option>
        <option value="2">Fevereiro</option>
        ...
        <option value="12">Dezembro</option>
    </select>
    <button type="submit">Filtrar</button>
</form>

<table>
    <tr>
        <th>Material</th>
        <th>Quantidade</th>
        <th>Data</th>
    </tr>

    <%
        int mes = request.getParameter("mes") == null ? 0 : Integer.parseInt(request.getParameter("mes"));

        if (mes > 0) {
            EntradaDAO dao = new EntradaDAO();
            List<Entrada> lista = dao.listarPorMes(mes);

            for (Entrada e : lista) {
    %>

    <tr>
        <td><%= e.getNomeMaterial() %></td>
        <td><%= e.getQuantidade() %></td>
        <td><%= e.getDataEntrada() %></td>
    </tr>

    <%      }
        }
    %>

</table>

</body>
</html>
