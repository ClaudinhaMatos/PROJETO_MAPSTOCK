<%-- 
    Document   : estoque_atual
    Created on : 26 de nov. de 2025, 00:22:59
    Author     : Claudinha
--%>

<%@page import="model.DAO.EstoqueDAO"%>
<%@page import="model.Material"%>
<%@page import="java.util.List"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    EstoqueDAO edao = new EstoqueDAO();
    List<Material> lista = edao.listarEstoque();
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Estoque Atual</title>
        <style>
            table {
                width: 80%;
                margin: 30px auto;
                border-collapse: collapse;
            }
            th, td {
                border: 1px solid #444;
                padding: 10px;
                text-align: center;
            }
            th {
                background: #f2f2f2;
            }
            .ok {
                background: #d4ffd4;
            }
            .baixo {
                background: #ffd4d4;
            }
            h2 {
                text-align: center;
                margin-top: 25px;
            }
        </style>
    </head>
    <body>

        <h2>Estoque Atual de Materiais</h2>

        <table>
            <tr>
                <th>Código</th>
                <th>Material</th>
                <th>Fabricante</th>
                <th>Qtd Mínima</th>
                <th>Qtd Atual</th>
                <th>Status</th>
            </tr>

            <%
                for (Material m : lista) {
                    String status = m.getEstoqueAtual() >= m.getQtd() ? "OK" : "BAIXO";
                    String classe = status.equals("OK") ? "ok" : "baixo";
            %>

            <tr class="<%= classe %>">
                <td><%= m.getId() %></td>
                <td><%= m.getNome() %></td>
                <td><%= m.getFab() %></td>
                <td><%= m.getQtd() %></td>
                <td><%= m.getEstoqueAtual() %></td>
                <td><%= status %></td>
            </tr>

            <% } %>
        </table>

    </body>
</html>
