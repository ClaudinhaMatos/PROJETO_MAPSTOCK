/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package model.DAO;

import config.ConectaDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Material;
import model.Entrada;

public class EntradaDAO {

    public void registrarEntrada(int idMaterial, int quantidade, int mes, String dataEntrada) throws ClassNotFoundException {

        String sql = "INSERT INTO registro_entrada (material_id, quantidade, mes, data_entrada) "
                   + "VALUES (?, ?, ?, ?)";

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idMaterial);
            stmt.setInt(2, quantidade);
            stmt.setInt(3, mes);
            stmt.setString(4, dataEntrada);

            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro ao registrar entrada: " + e.getMessage());
        }
    }

    public List<Entrada> listarEntradasPorMes(int mes) throws ClassNotFoundException {

        String sql = "SELECT e.material_id, m.nome, m.fabricante, e.quantidade, e.data_entrada "
                   + "FROM registro_entrada e "
                   + "JOIN materiais m ON e.material_id = m.id "
                   + "WHERE MONTH(e.data_entrada) = ? "
                   + "ORDER BY e.data_entrada DESC";

        List<Entrada> lista = new ArrayList<>();

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, mes);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Entrada ent = new Entrada();

                ent.setIdMaterial(rs.getInt("material_id"));
                ent.setNomeMaterial(rs.getString("nome"));
                ent.setFabricante(rs.getString("fabricante"));
                ent.setQuantidade(rs.getInt("quantidade"));
                ent.setData(rs.getString("data_entrada"));

                lista.add(ent);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}
