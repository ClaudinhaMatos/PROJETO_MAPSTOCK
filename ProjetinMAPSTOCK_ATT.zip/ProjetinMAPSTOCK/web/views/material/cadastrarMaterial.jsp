<%-- 
    Document   : cadastrarMaterial
    Created on : 27 de nov. de 2025, 21:37:28
    Author     : Claudinha
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Cadastrar Material</title>
    </head>
    <body>
        <h2>Cadastrar Material</h2>

        <form action="salvarMaterial.jsp" method="post">
            Nome: <input type="text" name="nome"><br>
            Fabricante: <input type="text" name="fab"><br>
            Quantidade mínima: <input type="number" name="qtd"><br>
            Preço unitário: <input type="text" name="preco"><br>

            <button type="submit">Salvar</button>
        </form>
    </body>
</html>
