<%-- 
    Document   : registro_entrada_action.jsp
    Created on : 27 de nov. de 2025, 23:38:49
    Author     : Claudinha
--%>

<%@page import="model.DAO.EntradaDAO"%>
<%@page import="model.DAO.MaterialDAO"%>
<%@page import="model.DAO.EstoqueDAO"%>
<%@page import="model.Material"%>
<%@page import="java.util.List"%>

<%
    request.setCharacterEncoding("UTF-8");

    String data = request.getParameter("data_entrada");
    int mes = Integer.parseInt(data.substring(5, 7));

    MaterialDAO mdao = new MaterialDAO();
    EntradaDAO edao = new EntradaDAO();
    EstoqueDAO estoqueDAO = new EstoqueDAO();

    List<Material> materiais = mdao.listar();

    int registrosSalvos = 0;

    for (Material mat : materiais) {

        String campo = "qtd_" + mat.getId();
        String valor = request.getParameter(campo);

        if (valor != null && !valor.isEmpty()) {

            int qtd = Integer.parseInt(valor);

            if (qtd > 0) {

                // Registrar entrada no hist�rico
                edao.registrarEntrada(mat.getId(), qtd, mes, data);

                // Atualizar estoque atual (somar ao estoque existente)
                estoqueDAO.aumentarEstoque(mat.getId(), qtd);

                registrosSalvos++;
            }
        }
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Entrada de Materiais</title>
</head>
<body>

<div class="box">
    <% if (registrosSalvos > 0) { %>
        <h2>? Reposi��o registrada com sucesso!</h2>
        <p><strong><%= registrosSalvos %></strong> materiais foram atualizados.</p>
    <% } else { %>
        <h2>Nenhum registro v�lido foi encontrado.</h2>
        <p>Informe ao menos uma quantidade maior que zero.</p>
    <% } %>

    <a href="registro_entrada.jsp">Voltar</a>
</div>

</body>
</html>