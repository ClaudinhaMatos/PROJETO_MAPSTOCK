<%-- 
    Document   : validarLogin
    Created on : 25 de nov. de 2025, 23:22:50
    Author     : Claudinha
--%>

<%@page import="model.DAO.UsuarioDAO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    String usuario = request.getParameter("usuario");
    String senha = request.getParameter("senha");

    UsuarioDAO dao = new UsuarioDAO();

    if (dao.validarUsuario(usuario, senha)) {
        // login OK → redireciona para index.jsp
        response.sendRedirect("index.jsp");
    } else {
        // erro → volta para login com mensagem
        response.sendRedirect("login.jsp?erro=1");
    }
%>
