<%-- 
    Document   : login
    Created on : 25 de nov. de 2025, 23:21:13
    Author     : Claudinha
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login - MapStock</title>
    <link rel="stylesheet" href="../css/pages/login.css">
</head>

<body>
    <div class="login-box">
        <h2>MapStock</h2>

        <form method="post" action="auth/validarLogin.jsp">
            <input type="text" name="usuario" placeholder="Usuário" required>
            <input type="password" name="senha" placeholder="Senha" required>

            <button type="submit">Entrar</button>
        </form>

        <% 
            if (request.getParameter("erro") != null) { 
        %>
            <p class="erro">Usuário ou senha incorretos!</p>
        <% 
            } 
        %>
    </div>
</body>
</html>

