<%-- 
    Document   : relatorio_entrada_resultado
    Created on : 28 de nov. de 2025, 00:07:08
    Author     : Claudinha
--%>

<%@page import="model.DAO.EntradaDAO"%>
<%@page import="model.Entrada"%>
<%@page import="java.util.List"%>

<%
    int mes = Integer.parseInt(request.getParameter("mes"));
    EntradaDAO edao = new EntradaDAO();
    List<Entrada> entradas = edao.listarEntradasPorMes(mes);
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relat�rio - Entradas</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            padding: 40px;
        }
        table {
            width: 100%;
            background: #fff;
            border-collapse: collapse;
            box-shadow: 0 3px 12px rgba(0,0,0,0.15);
            border-radius: 8px;
            overflow: hidden;
        }
        th {
            background: #0a66c2;
            color: #fff;
            padding: 12px;
        }
        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        .voltar {
            display: inline-block;
            margin-top: 20px;
            background: #444;
            padding: 10px 18px;
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
        }
        .voltar:hover {
            background: #222;
        }
    </style>
</head>
<body>

<h2>? Relat�rio de Entradas - M�s <%= mes %></h2>

<table>
    <thead>
        <tr>
            <th>C�digo</th>
            <th>Material</th>
            <th>Fabricante</th>
            <th>Quantidade</th>
            <th>Data da Entrada</th>
        </tr>
    </thead>

    <tbody>
        <%
            if (entradas.isEmpty()) {
        %>
            <tr>
                <td colspan="5">Nenhum registro encontrado para este m�s.</td>
            </tr>
        <%
            } else {
                for (Entrada ent : entradas) {
        %>
            <tr>
                <td><%= ent.getIdMaterial() %></td>
                <td><%= ent.getNomeMaterial() %></td>
                <td><%= ent.getFabricante() %></td>
                <td><%= ent.getQuantidade() %></td>
                <td><%= ent.getData() %></td>
            </tr>
        <%
                }
            }
        %>
    </tbody>
</table>

<a class="voltar" href="relatorio_entrada.jsp">Voltar</a>

</body>
</html>
