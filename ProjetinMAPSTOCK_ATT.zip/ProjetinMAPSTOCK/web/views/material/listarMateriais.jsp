<%-- 
    Document   : listmat
    Author     : Claudinha
--%>
<%@page import="model.Material"%>
<%@page import="model.DAO.MaterialDAO"%>
<%@page import="java.util.List"%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%@page import="java.util.List"%>
<%@page import="model.Material"%>
<%@page import="model.DAO.MaterialDAO"%>

<%
    MaterialDAO dao = new MaterialDAO();
    List<Material> lista = dao.listar();
%>

<!DOCTYPE html>
<html>
<head>
    <title>Lista de Materiais</title>
</head>
<body>

<h2>Materiais Cadastrados</h2>

<table border="1">
    <tr>
        <th>Código</th>
        <th>Nome</th>
        <th>Fabricante</th>
        <th>Qtd mínima</th>
        <th>Preço</th>
        <th>Ações</th>
    </tr>

<% for(Material m : lista){ %>
    <tr>
        <td><%= m.getId() %></td>
        <td><%= m.getNome() %></td>
        <td><%= m.getFab() %></td>
        <td><%= m.getQtd() %></td>
        <td>R$ <%= m.getPreco() %></td>
        <td>
            <a href="editarMaterial.jsp?id=<%= m.getId() %>">Editar</a> |
            <a href="excluirMaterial.jsp?id=<%= m.getId() %>">Excluir</a>
        </td>
    </tr>
<% } %>

</table>

</body>
</html>
