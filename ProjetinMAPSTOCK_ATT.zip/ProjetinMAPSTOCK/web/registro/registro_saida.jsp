<%@page import="model.DAO.RegistroSaidaDAO"%>
<%@page import="model.DAO.MaterialDAO"%>
<%@page import="model.DAO.EstoqueDAO"%>
<%@page import="model.Material"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    request.setCharacterEncoding("UTF-8");

    String data = request.getParameter("data_retirada");
    int mes = Integer.parseInt(data.substring(5, 7));

    MaterialDAO mdao = new MaterialDAO();
    RegistroSaidaDAO rdao = new RegistroSaidaDAO();
    EstoqueDAO estoqueDAO = new EstoqueDAO();

    List<Material> materiais = mdao.listar();

    int registrosSalvos = 0;

    for (Material mat : materiais) {

        String campo = "qtd_" + mat.getId();
        String valor = request.getParameter(campo);

        if (valor != null && !valor.isEmpty()) {

            int qtd = Integer.parseInt(valor);

            if (qtd > 0) {

                // Verificar estoque atual
                int estoqueAtual = estoqueDAO.getEstoqueAtual(mat.getId());

                if (estoqueAtual < qtd) {
    %>
                    <p style="color:red; font-size:18px;">
                        ❌ Estoque insuficiente para o material: <strong><%= mat.getNome() %></strong><br>
                        Estoque atual: <%= estoqueAtual %> | Tentativa de retirada: <%= qtd %>
                    </p>
    <%
                    continue; // pula este material
                }

                // Calcular custo
                float custo = qtd * mat.getPreco();

                // Registrar saída na tabela "registro_saida"
                rdao.registrarSaida(mat.getId(), qtd, custo, mes, data);

                /// Atualizar estoque
                estoqueDAO.reduzirEstoque(mat.getId(), qtd);

                registrosSalvos++;
            }
        }
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registro de Saída</title>
    <style>
        body {
            font-family: Arial;
            background: #f7f7f7;
            padding: 40px;
            text-align: center;
        }
        .box {
            width: 60%;
            margin: auto;
            padding: 25px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.15);
        }
        h2 {
            color: #333;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            padding: 10px 18px;
            background: #0a66c2;
            color: #fff;
            border-radius: 8px;
        }
        a:hover {
            background: #084a91;
        }
    </style>
</head>
<body>

<div class="box">
    <% if (registrosSalvos > 0) { %>
        <h2>✔ Registro de saída salvo com sucesso!</h2>
        <p><strong><%= registrosSalvos %></strong> materiais foram atualizados.</p>
    <% } else { %>
        <h2>Nenhum registro válido foi encontrado.</h2>
        <p>Preencha pelo menos uma quantidade maior que zero.</p>
    <% } %>

    <a href="registroSaida.html">Voltar</a>
</div>

</body>
</html>
                

 
