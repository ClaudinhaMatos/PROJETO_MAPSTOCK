/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

/**
 *
 * @author Claudinha
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import config.ConectaDB;

public class RegistroSaidaDAO {

    // =====================================================================
    // 1. REGISTRAR SAÍDA + ATUALIZAR ESTOQUE
    // =====================================================================

    public void registrarSaida(int idMaterial, int quantidade, float custo, int mes, String data)
            throws ClassNotFoundException {

        Connection conn = null;
        PreparedStatement pst = null;

        try {
            conn = ConectaDB.conectar();

            // Inserir no registro_de_saida
            String sql = "INSERT INTO registro_saida (id_material, quantidade, custo, mes, data_retirada) "
                       + "VALUES (?, ?, ?, ?, ?)";

            pst = conn.prepareStatement(sql);
            pst.setInt(1, idMaterial);
            pst.setInt(2, quantidade);
            pst.setFloat(3, custo);
            pst.setInt(4, mes);
            pst.setString(5, data);
            pst.executeUpdate();

            // Atualizar estoque
            atualizarEstoque(idMaterial, quantidade);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (pst != null) pst.close(); } catch (Exception ex) {}
            try { if (conn != null) conn.close(); } catch (Exception ex) {}
        }
    }

    private void atualizarEstoque(int idMaterial, int quantidade) throws ClassNotFoundException {
        Connection conn = null;
        PreparedStatement pst = null;

        try {
            conn = ConectaDB.conectar();

            String sql = "UPDATE estoque_atual SET qtd_atual = qtd_atual - ? WHERE id_material = ?";

            pst = conn.prepareStatement(sql);
            pst.setInt(1, quantidade);
            pst.setInt(2, idMaterial);
            pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (pst != null) pst.close(); } catch (Exception ex) {}
            try { if (conn != null) conn.close(); } catch (Exception ex) {}
        }
    }

    // =====================================================================
    // 2. SOMA TOTAL DOS GASTOS NO MÊS
    // =====================================================================

    public float getTotalGastoMes(int mes) throws ClassNotFoundException {

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        float total = 0;

        try {
            conn = ConectaDB.conectar();

            String sql = "SELECT SUM(custo) FROM registro_saida WHERE mes = ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, mes);

            rs = pst.executeQuery();

            if (rs.next()) {
                total = rs.getFloat(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ex) {}
            try { if (pst != null) pst.close(); } catch (Exception ex) {}
            try { if (conn != null) conn.close(); } catch (Exception ex) {}
        }

        return total;
    }

    // =====================================================================
    // 3. MÉDIA DE SAÍDAS DE UM MATERIAL NO MÊS
    // =====================================================================

    public float getMediaSaidasMaterial(int idMaterial, int mes) throws ClassNotFoundException {

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        float media = 0;

        try {
            conn = ConectaDB.conectar();

            String sql = "SELECT AVG(quantidade) FROM registro_saida "
                       + "WHERE id_material = ? AND mes = ?";

            pst = conn.prepareStatement(sql);
            pst.setInt(1, idMaterial);
            pst.setInt(2, mes);

            rs = pst.executeQuery();

            if (rs.next()) {
                media = rs.getFloat(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ex) {}
            try { if (pst != null) pst.close(); } catch (Exception ex) {}
            try { if (conn != null) conn.close(); } catch (Exception ex) {}
        }

        return media;
    }

}