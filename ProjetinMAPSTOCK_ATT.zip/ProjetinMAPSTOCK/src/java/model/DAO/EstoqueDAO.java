/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import config.ConectaDB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Material;

public class EstoqueDAO {

    // ===============================================================
    // 1. Inserir estoque inicial (usado ao cadastrar novo material)
    // ===============================================================
    public void inserirEstoqueInicial(int idMaterial, int quantidade) throws ClassNotFoundException {
        String sql = "INSERT INTO estoque_atual (id_material, qtd_atual) VALUES (?, ?)";

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, idMaterial);
            pst.setInt(2, quantidade);
            pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ===============================================================
    // 2. Reduzir estoque (saída)
    // ===============================================================
    public void reduzirEstoque(int idMaterial, int quantidade) throws ClassNotFoundException {
        String sql = "UPDATE estoque_atual SET qtd_atual = qtd_atual - ? WHERE id_material = ?";

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, quantidade);
            pst.setInt(2, idMaterial);
            pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ===============================================================
    // 3. Aumentar estoque (entrada / reposição)
    // ===============================================================
    public void aumentarEstoque(int idMaterial, int quantidade) throws ClassNotFoundException {
        String sql = "UPDATE estoque_atual SET qtd_atual = qtd_atual + ? WHERE id_material = ?";

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, quantidade);
            pst.setInt(2, idMaterial);
            pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ===============================================================
    // 4. Obter quantidade atual
    // ===============================================================
    public int getEstoqueAtual(int idMaterial) throws ClassNotFoundException {
        String sql = "SELECT qtd_atual FROM estoque_atual WHERE id_material = ?";
        int qtd = 0;

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, idMaterial);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                qtd = rs.getInt("qtd_atual");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return qtd;
    }

    // ===============================================================
    // 5. Listar estoque completo (para tela Estoque Atual)
    // ===============================================================
    public List<Material> listarEstoque() throws ClassNotFoundException {
        String sql = "SELECT m.codigo, m.nome, m.fabricante, m.qtd_minima, m.preco_unit, e.qtd_atual "
                   + "FROM materiais m "
                   + "JOIN estoque_atual e ON m.codigo = e.id_material "
                   + "ORDER BY m.nome";

        List<Material> lista = new ArrayList<>();

        try (Connection conn = ConectaDB.conectar();
             PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Material mat = new Material();

                mat.setId(rs.getInt("codigo"));
                mat.setNome(rs.getString("nome"));
                mat.setFab(rs.getString("fabricante"));
                mat.setQtd(rs.getInt("qtd_minima"));
                mat.setPreco(rs.getFloat("preco_unit"));
                mat.setEstoqueAtual(rs.getInt("qtd_atual"));

                lista.add(mat);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

}
