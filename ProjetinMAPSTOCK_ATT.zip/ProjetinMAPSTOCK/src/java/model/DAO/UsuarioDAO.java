/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.DAO;

import java.sql.*;
import model.Material;
import config.ConectaDB;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Claudinha
 */
public class UsuarioDAO {
    public boolean validarUsuario(String usuario, String senha) {
        boolean autenticado = false;

        try {
            Connection conn = ConectaDB.conectar();
            String sql = "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, usuario);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                autenticado = true;
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return autenticado;
    }
}
