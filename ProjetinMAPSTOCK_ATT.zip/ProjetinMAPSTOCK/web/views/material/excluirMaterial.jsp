<%-- 
    Document   : excluirMaterial
    Created on : 27 de nov. de 2025, 21:40:27
    Author     : Claudinha
--%>

<%@page import="model.DAO.MaterialDAO"%>
<%@page import="model.Material"%>
<%
    int id = Integer.parseInt(request.getParameter("id"));
    MaterialDAO dao = new MaterialDAO();
    Material m = dao.buscarPorId(id);
%>

<!DOCTYPE html>
<html>
<head>
    <title>Excluir Material</title>
</head>
<body>

<h2>Excluir Material</h2>

<p>Tem certeza que deseja excluir o material: <strong><%= m.getNome() %></strong>?</p>

<form action="excluirMaterialAction.jsp" method="post">
    <input type="hidden" name="id" value="<%= m.getId() %>">
    <button type="submit">Confirmar exclus�o</button>
</form>

</body>
</html>
