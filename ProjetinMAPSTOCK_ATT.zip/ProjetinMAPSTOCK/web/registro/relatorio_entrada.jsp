<%-- 
    Document   : relatorio_entrada
    Created on : 28 de nov. de 2025, 00:05:59
    Author     : Claudinha
--%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relat�rio Mensal - Entradas</title>
    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .box {
            background: #fff;
            padding: 25px;
            width: 380px;
            border-radius: 10px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.15);
            text-align: center;
        }
        select, button {
            padding: 10px;
            margin-top: 15px;
            width: 100%;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            background: #0a66c2;
            color: white;
            cursor: pointer;
        }
        button:hover {
            background: #084a91;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>? Relat�rio Mensal de Entradas</h2>

    <form action="relatorio_entrada_resultado.jsp" method="GET">
        <label>M�s:</label>
        <select name="mes" required>
            <option value="">Selecione...</option>
            <%
                for (int i = 1; i <= 12; i++) {
            %>
                <option value="<%= i %>"><%= i %></option>
            <%
                }
            %>
        </select>

        <button type="submit">Gerar Relat�rio</button>
    </form>
</div>

</body>
</html>
