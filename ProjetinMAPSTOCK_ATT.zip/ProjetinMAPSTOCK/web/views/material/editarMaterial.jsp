<%-- 
    Document   : editarMaterial
    Created on : 27 de nov. de 2025, 21:39:27
    Author     : Claudinha
--%>

<%@page contentType="text/html; charset=UTF-8"%>
<%@page import="model.Material"%>
<%@page import="model.DAO.MaterialDAO"%>

<%
    int id = Integer.parseInt(request.getParameter("id"));
    MaterialDAO dao = new MaterialDAO();
    Material mat = dao.buscarPorId(id);
%>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Material</title>
</head>
<body>

<h2>Editar Material</h2>

<form action="salvarEdicao.jsp" method="post">
    <input type="hidden" name="id" value="<%= mat.getId() %>">

    Nome: <input type="text" name="nome" value="<%= mat.getNome() %>"><br>
    Fabricante: <input type="text" name="fab" value="<%= mat.getFab() %>"><br>
    Quantidade mínima: <input type="number" name="qtd" value="<%= mat.getQtd() %>"><br>
    Preço unitário: <input type="text" name="preco" value="<%= mat.getPreco() %>"><br>

    <button type="submit">Salvar alterações</button>
</form>

</body>
</html>
