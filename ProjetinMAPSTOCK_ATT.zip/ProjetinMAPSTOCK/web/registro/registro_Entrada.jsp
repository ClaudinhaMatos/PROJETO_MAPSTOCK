<%-- 
    Document   : registro_Entrada
    Created on : 27 de nov. de 2025, 23:37:53
    Author     : Claudinha
--%>

<%@page import="model.Material"%>
<%@page import="model.DAO.MaterialDAO"%>
<%@page import="java.util.List"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registro de Entrada</title>
    <link rel="stylesheet" href="../css/pages/registro_entrada.css"/>
</head>
<body>

<div class="container">

    <h2>Registro de Entrada / Reposi��o</h2>

    <form action="registro_entrada_action.jsp" method="post">

        <label>Data da Reposi��o:</label>
        <input type="date" name="data_entrada" required>

        <table>
            <tr>
                <th>Material</th>
                <th>Quantidade Adicionada</th>
            </tr>

            <%
                MaterialDAO dao = new MaterialDAO();
                List<Material> lista = dao.listar();

                for (Material m : lista) {
            %>

            <tr>
                <td><%= m.getNome() %></td>
                <td>
                    <input type="number" name="qtd_<%= m.getId() %>" min="0">
                </td>
            </tr>

            <% } %>

        </table>

        <button class="btn" type="submit">Registrar Entrada</button>

    </form>

</div>

</body>
</html>